# Intel AI Flame Graph

## Instructions
- Run the provided script to begin profiling:
        ```sudo ./aiflamegraph.sh```
- Interrupt the script with `ctrl-C` to stop profiling.
- Open the generated flame graph SVG file in a browser or other image viewer.
